package com.example.templatemethodpattern

class Coffee : CaffeineBeverage() {
//    override fun prepareRecipe(){
//        boilWater()
//        brewCoffeeGrinds()
//        pourInCup()
//        addSugarAndMilk()
//    }
//    fun boilWater(){}
//    fun pourInCup(){}

//    private fun brewCoffeeGrinds(){
//        println("Dripping Coffee through filter")
//    }
//    private fun addSugarAndMilk(){
//        println("Adding Sugar and milk")
//    }

    override fun brew() {
        println("Dripping Coffee through filter")
    }
    override fun addCondiments() {
        println("Adding Sugar and milk")
    }


}