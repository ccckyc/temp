package com.example.templatemethodpattern

abstract class CaffeineBeverage {

    fun prepareRecipe(){
        boilWater()
        pourInCup()

        brew()
        addCondiments()
    }

    abstract fun addCondiments()

    abstract fun brew()

    private fun boilWater(){
        println("Boiling Water")
    }
    private fun pourInCup(){
        println("Pouring into cup")
    }
}