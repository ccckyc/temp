package com.example.zooviewpager.fragment

import android.annotation.SuppressLint
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.databinding.ViewDataBinding
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.zookotlin.util.Parameter
import com.example.zooviewpager.MyApplication
import com.example.zooviewpager.data.detail.ViewModelClass

abstract class BaseFragment<T : ViewDataBinding, VM : ViewModel> : Fragment(), ViewModelClass<VM> {
    private var mTampDataBinding: T? = null
    protected val mDataBinding: T get() = mTampDataBinding!!
    protected val mViewModel: VM by lazy { ViewModelProvider(this)[mClass] }

    protected var mTitle = Parameter.getInstance().mKeyAnimal
    abstract val mLayout: Int
    lateinit var mGoToPageApplication: MyApplication


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View? {
//        mDataBinding -> AllAreaRecyclerviewBinding
        mViewModel
        mGoToPageApplication = requireActivity().application as MyApplication
        mGoToPageApplication.setFragmentManager(requireActivity().supportFragmentManager)

        val iData = DataBindingUtil.inflate<ViewDataBinding>(inflater, mLayout, container, false)
        mTampDataBinding = iData as T
        return iData?.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        getBundle()

        val fm = parentFragmentManager //        getBackStackEntryCount() 返回總數量

        for (entry in 0 until fm.backStackEntryCount) {
//            Log.v("aaa", "BaseFragment ----- Count ----- = " + fm.getBackStackEntryAt(entry).id.toString())
        }

        uiInit(mTitle)
    }

    //取到 點擊bundle傳來的TitleName
    @SuppressLint("LongLogTag")
    protected open fun getBundle() {
        val iBundle = arguments
        if (iBundle != null) {
            //點節Home按鈕才會傳Bundle
            mTitle = iBundle.getString(Parameter.getInstance().mKeyTitle).toString() //館區簡介
        }
    }


    abstract fun uiInit(pTitle: String?)
}