package com.example.commandpattern.command

import com.example.commandpattern.equipment.CeilingLight
import com.example.commandpattern.Command

class CeilingLightOnCommand(private val mEquipment: CeilingLight) : Command {
    override fun execute() {
        mEquipment.on()

    }

    override fun undo() {
        mEquipment.off()
    }


}