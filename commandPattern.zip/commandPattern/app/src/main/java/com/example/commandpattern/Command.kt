package com.example.commandpattern

interface Command {
    fun execute()
    fun undo()// 全部關閉
}