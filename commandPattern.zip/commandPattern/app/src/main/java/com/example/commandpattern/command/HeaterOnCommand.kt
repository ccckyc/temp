package com.example.commandpattern.command

import com.example.commandpattern.equipment.Heater
import com.example.commandpattern.Command

class HeaterOnCommand(private val mEquipment: Heater) : Command {

    override fun execute() {
        mEquipment.on()

    }

    override fun undo() {
        mEquipment.off()
    }


}