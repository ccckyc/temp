package com.example.commandpattern.command

import com.example.commandpattern.equipment.Light
import com.example.commandpattern.Command

class LightOnCommand(private val mEquipment: Light) : Command {

    override fun execute() {
        mEquipment.on()
    }

    override fun undo() {
        mEquipment.off()
    }


}