package com.example.commandpattern

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.command_pattern.RemoteControl
import com.example.commandpattern.command.CeilingLightOnCommand
import com.example.commandpattern.command.*
import com.example.commandpattern.equipment.CeilingLight
import com.example.commandpattern.equipment.Heater
import com.example.commandpattern.equipment.Light

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val iLight = Light("Yi Chen Light")
        val iLightOn = LightOnCommand(iLight)
        val iLightOff = LightOffCommand(iLight)
        val iRemote = RemoteControl()

        iRemote.setCommand(0, iLightOn, iLightOff) // Light ON
        iRemote.onButtonWasPressed(0)
        iRemote.offButtonWasPressed(0)



        val iCeilingLight = CeilingLight("Yi Chen CeilingLight")
        val iCeilingLightOn = CeilingLightOnCommand(iCeilingLight)
        val iCeilingLightOff = CeilingLightOffCommand(iCeilingLight)
//        val iRemote = RemoteControl()

        iRemote.setCommand(1, iCeilingLightOn, iCeilingLightOff) // Light ON
        iRemote.onButtonWasPressed(1)
        iRemote.offButtonWasPressed(1)



        val iHeater = Heater("Yi Chen Heater")
        val iHeaterOn = HeaterOnCommand(iHeater)
        val iHeaterOff = HeaterOffCommand(iHeater)
//        val iRemote = RemoteControl()

        iRemote.setCommand(2, iHeaterOn, iHeaterOff) // 插槽對應點
        iRemote.onButtonWasPressed(2)
        iRemote.offButtonWasPressed(2)
        iRemote.offButtonWasPressed(2)
        iRemote.onDoButtonWasPressed()
    }
}