package com.example.commandpattern

import com.example.commandpattern.Command

class SimpleRemoteControl(private var mSlot: Command) {

    fun setCommand(pCommand: Command) {
        mSlot = pCommand
    }

    fun buttonWasPressed() {
        mSlot.execute()
    }


}