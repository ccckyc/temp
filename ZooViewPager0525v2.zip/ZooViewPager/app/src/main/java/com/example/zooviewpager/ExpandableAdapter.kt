package com.example.zooviewpager

import android.annotation.SuppressLint
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ExpandableAdapter : RecyclerView.Adapter<ExpandableAdapter.ViewHolder>() {
    private val mExpandableDataList = ArrayList<String>()
    private var mExpandableRecyclerView: OnExpandableListener? = null
    private var mClickListen = -1


    @SuppressLint("NotifyDataSetChanged")
    fun setData(pList: ArrayList<String>?, pExpandableRecyclerView: OnExpandableListener?) {
        mExpandableRecyclerView = pExpandableRecyclerView
        mExpandableDataList.clear()
        if (pList != null) {
            mExpandableDataList.addAll(pList)
        }
        notifyDataSetChanged()
    }

    override fun getItemCount(): Int {
        return mExpandableDataList.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.mItemTextView.text = mExpandableDataList[position]

//        if (mClickListen == position){
//            holder.mItemTextView.setBackgroundColor(Color.CYAN)
//        }else{
//            holder.mItemTextView.setBackgroundColor(0)
//        }

        holder.mItemTextView.setOnClickListener {
            mClickListen = mExpandableRecyclerView?.onExpandableBtnClick(position) ?: -1
            notifyDataSetChanged()
        }

    }

    class ViewHolder(iView: View) : RecyclerView.ViewHolder(iView) {
        var mItemTextView: TextView = iView.findViewById(R.id.mTvExpandItem)


    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val iView: View =
            LayoutInflater.from(parent.context).inflate(R.layout.expandable_item, parent, false)
        return ViewHolder(iView)
    }

    interface OnExpandableListener {
        fun onExpandableBtnClick(position: Int): Int
    }
}
