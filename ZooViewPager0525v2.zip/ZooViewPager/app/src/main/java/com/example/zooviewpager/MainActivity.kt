package com.example.zooviewpager

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import com.example.zooviewpager.databinding.ActivityMainBinding
import com.example.zooviewpager.viewPager2.ListViewPage


class MainActivity : AppCompatActivity() {
    private var mActivityMainBinding: ActivityMainBinding? = null

    companion object {
        val mGoToPageApplication: MyApplication by lazy {
            mTampSaveGoToPageApplication!!
        }
        private var mTampSaveGoToPageApplication: MyApplication? = null
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mActivityMainBinding = DataBindingUtil.setContentView(this, R.layout.activity_main)


        if (savedInstanceState == null) {
            mTampSaveGoToPageApplication = application as MyApplication
            mGoToPageApplication.setFragmentManager(this.supportFragmentManager)

            mGoToPageApplication.goToPage(pTargetFragment = ListViewPage())

//                if (intent.extras != null) { //有值
//
//                    // Fragment關係
//                    Handler(Looper.getMainLooper()).postDelayed({
//                        // onNewIntent 跳太快，要讓他延遲一下下
//                        onNewIntent(intent)
//                    }, 500)
//                }

//                Log.v("--aaa--", "intent.extras  = " + intent.extras)

        }
    }


}