package com.example.zooviewpager.data.detail

interface ViewModelClass<ClassData> {

    val mClass: Class<ClassData>
}