package com.example.zooviewpager.viewPager2

import android.animation.ObjectAnimator
import android.util.Log
import android.widget.ImageView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.viewpager2.widget.ViewPager2.OnPageChangeCallback
import com.example.zookotlin.util.Parameter
import com.example.zooviewpager.AllViewModel
import com.example.zooviewpager.ExpandableAdapter
import com.example.zooviewpager.R
import com.example.zooviewpager.databinding.ListPageBinding
import com.example.zooviewpager.fragment.BaseFragment
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayout.OnTabSelectedListener
import com.google.android.material.tabs.TabLayoutMediator


class ListViewPage : BaseFragment<ListPageBinding, AllViewModel>(), ExpandableAdapter.OnExpandableListener {
    override val mLayout: Int get() = R.layout.list_page
    override val mClass: Class<AllViewModel> get() = AllViewModel::class.java
    private val mViewPageCount = 5

    private val mArrayTab = ArrayList<String>()

    override fun uiInit(pTitle: String?) {
        mDataBinding.mllBtn.setOnClickListener {
            val toggle = mDataBinding.mExpandRecyclerView.mExpandLinearLayout.toggle()
//            mDataBinding.mTvTip.text = if (toggle) "收起" else "展开"
            startImageRotate(mDataBinding.mImgArrow, toggle)
        }
        init()

    }

    /**
     * ListFragment尚未建立完成，lazy讓他等Fragment建立完
     */
    private val mViewPagerAdapter by lazy {
        ViewPagerAdapter(this, 0)
    }
    private val mExpandableAdapter by lazy {
        ExpandableAdapter()
    }

    /**
     * 旋转箭头图标
     */
    private fun startImageRotate(imageView: ImageView, toggle: Boolean) {
        val tarRotate: Float = if (toggle) {
            180f
        } else {
            0f
        }

        imageView.apply {
            ObjectAnimator.ofFloat(this, "rotation", rotation, tarRotate).let {
                it.duration = 150
                it.start()
            }
        }
    }

    private fun init() {
//        val mArrayTab = ArrayList<String>()

        // 設定TabLayout
        for (i in 1..mViewPageCount) { i
            mArrayTab.add(Parameter.getInstance().mKeyAnimal + i)
        }
        for (i in 1..mViewPageCount) {
            mArrayTab.add(Parameter.getInstance().mKeyPlant + i)
        }


        mDataBinding.mViewPager.adapter = mViewPagerAdapter
        mViewPagerAdapter.viewIsFrontGround(0)

        mViewPagerAdapter.setData(mArrayTab.size)


        val mExpandableAdapter = mExpandableAdapter
        val mGridLayoutManager = GridLayoutManager(activity, 3)
        mExpandableAdapter.setData(mArrayTab, this)
        mDataBinding.mExpandRecyclerView.mExpandRecyclerView.layoutManager = mGridLayoutManager
        mDataBinding.mExpandRecyclerView.mExpandRecyclerView.adapter = mExpandableAdapter



        TabLayoutMediator(mDataBinding.mTabLayout, mDataBinding.mViewPager) { pTab, pPosition ->
            Log.v("aaa", "pPosition = $pPosition")
            pTab.text = mArrayTab[pPosition]
        }.attach()
//
        mDataBinding.mTabLayout.addOnTabSelectedListener(object: OnTabSelectedListener{
            override fun onTabSelected(tab: TabLayout.Tab?) {
                // 判斷已點擊的Tab
                Log.v("aaax", "onTabSelected = ${tab?.position}")
//                mViewPagerAdapter.viewIsFrontGround(tab?.position)
                tab?.let {
                    mViewPagerAdapter.viewIsFrontGround(it.position)
                    //確定viewpager 的fragment在前景真正call api onTabReselected
//                    reTouchTabOnFrontGroundSingle(it)
                }

            }

            override fun onTabUnselected(tab: TabLayout.Tab?) {
                Log.v("aaax", "onTabUnselected = ${tab?.position}")
            }

            override fun onTabReselected(tab: TabLayout.Tab?) {
                Log.v("aaax", "onTabReselected = ${tab?.position}")
//                mViewPagerAdapter.viewIsFrontGround(tab?.position)
            }

        })

//        reTouchTabOnFrontGroundSingle(mDataBinding.mTabLayout.getTabAt(0))
//
//        mDataBinding.mTabLayout.addOnTabSelectedListener(object : OnTabSelectedListener {
//            override fun onTabSelected(tab: TabLayout.Tab) {
//                mDataBinding.mViewPager.setCurrentItem(tab.position)
//                Log.v("aaa", "tab.position = "+tab.position)
//            }
//
//            override fun onTabUnselected(tab: TabLayout.Tab) {}
//            override fun onTabReselected(tab: TabLayout.Tab) {}
//        })

        mDataBinding.mViewPager.registerOnPageChangeCallback(object : OnPageChangeCallback() {
            override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int
            ) {
                super.onPageScrolled(position, positionOffset, positionOffsetPixels)
//                Log.v("aaa", "position ListViewPage = "+ position)
//                Toast.makeText(requireContext(), "page selected $position", Toast.LENGTH_SHORT).show()
            }
        })




//        mDataBinding.mViewPager.setCurrentItem(0, false)
    }

    private fun reTouchTabOnFrontGroundSingle(tabAt: TabLayout.Tab?) {
//        Handler(Looper.getMainLooper()).postDelayed({
            mDataBinding.mTabLayout.selectTab(tabAt)
//        }, 200)
    }

    override fun onExpandableBtnClick(position: Int): Int {
        mDataBinding.mViewPager.currentItem = position
        mDataBinding.mTabLayout.selectTab(mDataBinding.mTabLayout.getTabAt(position))
        return position
    }


}