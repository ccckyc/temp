package com.example.commandpattern

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import android.widget.ToggleButton
import com.example.commandpattern.remoteControl.RemoteControl
import com.example.commandpattern.command.*
import com.example.commandpattern.equipment.CeilingLight
import com.example.commandpattern.equipment.Heater
import com.example.commandpattern.equipment.Light

class MainActivity : AppCompatActivity() { //, View.OnClickListener
    private lateinit var mONOFF : ToggleButton
    private lateinit var mEquipment: TextView
    private lateinit var btOne: Button

    private val mRemote = RemoteControl()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)




        setCommands()
        btnOnOff()
    }

    @SuppressLint("ResourceType")
    private fun btnOnOff() {
        mONOFF = findViewById(R.id.mToggleBtnOnOff)
        mEquipment = findViewById(R.id.mEquipment)


        mONOFF.setOnCheckedChangeListener { _, isChecked ->
            if(isChecked) {
                mRemote.onButtonWasPressed(0)
                mEquipment.text = mONOFF.text

            }else{
                mRemote.offButtonWasPressed(0)
                mEquipment.text = mONOFF.text
            }
        }

    }

    private fun setCommands() {
        val iLight = Light("Yi Chen Light")
        val iLightOn = LightOnCommand(iLight)
        val iLightOff = LightOffCommand(iLight)
//        val iRemote = RemoteControl()

        mRemote.setCommand(0, iLightOn, iLightOff) // Light ON
        mRemote.onButtonWasPressed(0)
        mRemote.offButtonWasPressed(0)



        val iCeilingLight = CeilingLight("Yi Chen CeilingLight")
        val iCeilingLightOn = CeilingLightOnCommand(iCeilingLight)
        val iCeilingLightOff = CeilingLightOffCommand(iCeilingLight)
//        val iRemote = RemoteControl()

        mRemote.setCommand(1, iCeilingLightOn, iCeilingLightOff) // Light ON
        mRemote.onButtonWasPressed(1)
        mRemote.offButtonWasPressed(1)



        val iHeater = Heater("Yi Chen Heater")
        val iHeaterOn = HeaterOnCommand(iHeater)
        val iHeaterOff = HeaterOffCommand(iHeater)
//        val iRemote = RemoteControl()

        mRemote.setCommand(2, iHeaterOn, iHeaterOff) // 插槽對應點
        mRemote.onButtonWasPressed(2)
        mRemote.offButtonWasPressed(2)
        mRemote.offButtonWasPressed(2)
        mRemote.onDoButtonWasPressed()
    }
}