package com.example.commandpattern.command

import com.example.commandpattern.equipment.Heater

class HeaterOffCommand(private val mEquipment: Heater) : Command {
    override fun execute() {
        mEquipment.off()
    }

    override fun undo() {
        mEquipment.off()
    }
}