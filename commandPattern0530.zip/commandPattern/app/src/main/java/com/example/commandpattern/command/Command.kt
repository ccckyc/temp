package com.example.commandpattern.command

interface Command {
    fun execute()
    fun undo()// 全部關閉
}