package com.example.commandpattern.command

import com.example.commandpattern.equipment.CeilingLight


class CeilingLightOffCommand(private val mEquipment: CeilingLight) : Command {
    override fun execute() {
        mEquipment.off()
    }

    override fun undo() {
        mEquipment.off()
    }
}