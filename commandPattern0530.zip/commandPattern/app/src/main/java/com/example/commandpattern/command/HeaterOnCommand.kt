package com.example.commandpattern.command

import com.example.commandpattern.equipment.Heater

class HeaterOnCommand(private val mEquipment: Heater) : Command {

    override fun execute() {
        mEquipment.on()

    }

    override fun undo() {
        mEquipment.off()
    }


}