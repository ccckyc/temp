package com.example.commandpattern.command

import com.example.commandpattern.equipment.Light

class LightOffCommand(private val mEquipment: Light) : Command {
    override fun execute() {
        mEquipment.off()
    }

    override fun undo() {
        mEquipment.off()
    }
}