package com.example.commandpattern.equipment

import android.util.Log


class Light(private val mName: String) {

    fun on() {
        Log.v("aaa", this.javaClass.simpleName + " " + mName + " ON")
    }

    fun off() {
        Log.v("aaa", this.javaClass.simpleName + " " + mName + " OFF")
    }

}