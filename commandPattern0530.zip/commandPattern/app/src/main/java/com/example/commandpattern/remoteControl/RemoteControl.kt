package com.example.commandpattern.remoteControl

import com.example.commandpattern.command.Command

class RemoteControl {

    private val mOnCommands = arrayListOf<Command>()
    private val mOffCommands = arrayListOf<Command>()


    fun setCommand(pSlot: Int, pOnCommand: Command, pOffCommand: Command) {
        mOnCommands.add(pSlot, pOnCommand)
        mOffCommands.add(pSlot, pOffCommand)
    }

    fun onButtonWasPressed(pSlot: Int) {
        mOnCommands[pSlot].execute() //get
    }

    fun offButtonWasPressed(pSlot: Int) {
        mOffCommands[pSlot].execute()
    }

    fun onDoButtonWasPressed(){
        for( iOff in mOffCommands) {
            iOff.undo()
        }
    }

}