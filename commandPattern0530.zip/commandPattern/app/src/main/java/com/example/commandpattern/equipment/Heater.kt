package com.example.commandpattern.equipment

import android.util.Log


class Heater(private val mName: String) {
    // execute hot

    // undo
    // hot to warm
    // warm to hot
    // off

    private val mTypeWarm: Int = 1
    private val mTypeHot: Int = 2
    private val mTypeOff: Int = 3
    private var mTemp: Int = 0


    fun on() {
        mTemp = mTypeHot
        Log.v("aaa", this.javaClass.simpleName + " " + mName + " Hot")
    }

    fun off() {
        val iHeaterType = if (mTemp == mTypeHot) {
            mTemp = mTypeWarm
            " Warm"
        } else if (mTemp == mTypeWarm) {
            mTemp = mTypeOff
            " Off"
        } else {
            mTemp = mTypeOff
            " Off"
        }

        Log.v("aaa", this.javaClass.simpleName + " " + mName + iHeaterType)
    }
}