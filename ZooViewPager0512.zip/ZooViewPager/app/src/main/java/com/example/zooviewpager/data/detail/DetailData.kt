package com.example.zooviewpager.data.detail

import com.example.zookotlin.data.detail.ItfDetail

class DetailData {
    private var mDetail: ItfDetail? = null

    fun setAnimal(pString: String?): ItfDetail? {
        mDetail = AnimalDetailData()
        (mDetail as AnimalDetailData).setData(pString)
        return mDetail
    }

    fun setPlant(pString: String?): ItfDetail? {
        mDetail = PlantDetailData()
        (mDetail as PlantDetailData).setData(pString)
        return mDetail
    }

    fun setArea(pString: String?): ItfDetail? {
        mDetail = AreaDetailData()
        (mDetail as AreaDetailData).setData(pString)
        return mDetail
    }
}