package com.example.zooviewpager.fragment

import android.annotation.SuppressLint
import android.util.Log
import android.webkit.WebViewClient
import com.example.zooviewpager.AllViewModel
import com.example.zooviewpager.R
import com.example.zooviewpager.databinding.VideoBinding

class VideoFragment : BaseFragment<VideoBinding, AllViewModel>() {
//    private var mVideoBinding: VideoBinding? = null
    private var mVideo: String? = null
    private var mUrl: String? = null

    override val mClass: Class<AllViewModel> get() = AllViewModel::class.java
    override val mLayout: Int get() = R.layout.video

    override fun uiInit(pTitle: String?) {
        getData()
    }

//    override fun onCreate(savedInstanceState: Bundle?) {
//        super.onCreate(savedInstanceState)
//        mDataBinding = DataBindingUtil.setContentView(this, R.layout.video)
//        getData()
//    }

    @SuppressLint("SetJavaScriptEnabled")
    fun getData() {
//        val iIntent = intent
        val iBundle = arguments
        mDataBinding.mUrl.settings.javaScriptEnabled = true
        mDataBinding.mUrl.webViewClient = WebViewClient()

        if (iBundle?.getString("vedio") != null) {
//            mVideo = iIntent.getStringExtra("vedio")
            mVideo = iBundle.getString("vedio")
            mDataBinding.mUrl.loadUrl(mVideo!!)
            Log.v("aaa----video", mVideo!!)
        } else {
//            mUrl = iIntent.getStringExtra("Url")
            mUrl = iBundle?.getString("Url")
            mDataBinding.mUrl.loadUrl(mUrl!!)
            Log.v("aaa----Url", mUrl!!)
        }
    }
}
