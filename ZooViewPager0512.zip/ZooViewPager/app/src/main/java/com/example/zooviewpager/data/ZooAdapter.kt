package com.example.zooviewpager.data

import android.annotation.SuppressLint
import android.content.Context
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.zooviewpager.fragment.DetailFragment
import com.example.zookotlin.util.Parameter
import com.example.zooviewpager.MainActivity.Companion.mGoToPageApplication
import com.example.zooviewpager.R
import com.example.zooviewpager.data.list.ListData
import com.example.zooviewpager.roomDataBase.AppDatabase
import com.example.zooviewpager.roomDataBase.MyData
import java.util.*

class ZooAdapter (private var pTitle: String?) : RecyclerView.Adapter<ZooAdapter.ViewHolder>() {
    private val mDataResult: ArrayList<ListData> = ArrayList<ListData>()
    private val mArraySelected = ArrayList<Int>()
    private val mHandler = Handler(Looper.getMainLooper())
    private val mSynchronizedUsed = "aaa"
    private val mRunnable = Runnable { changeUi() }
    private var mChangeLayout = false

    private var mActivity: AppCompatActivity? = null
//    private var mTitle = pTitle
    private var mPosition = 0



    @SuppressLint("NotifyDataSetChanged")
    fun setData(pData: ArrayList<ListData>?) {
//        if (pData != null) {
            mDataResult.addAll(pData!!)//傳資料到 mDataResult
//        }
        notifyDataSetChanged()
    }

//    fun setBtnChange(pLayoutManager: Boolean) {
//        mChangeLayout = pLayoutManager
//    }

    @SuppressLint("SetTextI18n", "LongLogTag")
    override fun onBindViewHolder(
        viewHolder: ViewHolder,
        @SuppressLint("RecyclerView") pPosition: Int,
    ) {
        val iListData: ListData = mDataResult[pPosition]
        //抓資料庫已點擊過的顯示出來  -->點過幾筆就會run幾次
        getRoomQuery(
            pTitle,
            iListData.getNameCh(),
            iListData.getNameEn(),
            pPosition,
            viewHolder.itemView.context
        )


        //--------
        //圖片有網址的但顯示不出來，做處理
        val iNewUrl: String = iListData.getPic01Url()!!.replace("?", "")

        //塞資料進去UI
        Glide.with(viewHolder.mImg.context)
            .load(iNewUrl)
            .error(R.drawable.zoo_logo)
            .placeholder(R.drawable.loading)
            .into(viewHolder.mImg)


        //-------
        viewHolder.mTextIndex.text = "" + pPosition
        viewHolder.mTvNameCh.text = iListData.getNameCh()

        //Area沒有mTvNameEn -->要做判斷if(  length() !=0  )
        if (iListData.getNameEn()!!.isNotEmpty()) {
            viewHolder.mTvNameEn.text = iListData.getNameEn() //.toString().replace("\"","")
        } else {
            viewHolder.mTvNameEn.visibility = View.GONE
        }
        viewHolder.mLayout.setBackgroundResource(R.drawable.layout_item_init_radius) //原本是 0


        //被點擊過呈現的layout樣式
        if (mArraySelected.contains(pPosition)) {
            viewHolder.mLayout.setBackgroundResource(R.drawable.layout_item_click_radius)
        } else {
            viewHolder.mLayout.setBackgroundResource(R.drawable.layout_item_init_radius)
        }


        //點擊下mLayout 做跳頁到 detail
        viewHolder.mLayout.tag = pPosition
        viewHolder.mLayout.setOnClickListener { view: View ->
            if (view.tag != null) {
                try {
                    val iId = view.tag.toString()
                    if (Character.isDigit(iId[0])) {
                        mPosition = iId.toInt()
                        mActivity = view.context as AppCompatActivity


                        /**
                         * 點擊跳轉到DetailFragment()頁面，傳TitleName
                         */
                        sendBundleGoOtherPage(pTitle)


                        setRoom(pTitle, iListData.getNameCh(), iListData.getNameEn(), pPosition, view.context)

                        //點擊過的標記
                        view.setBackgroundResource(R.drawable.layout_item_click_radius)
                        mArraySelected.add(mPosition)
                    }
                } catch (ignored: Exception) {

                }
            }
        }
    }

    private fun setRoom(
        pTitle: String?,
        pNameCh: String?,
        pNameEn: String?,
        pPosition: Int,
        pContext: Context?,
    ) {
        Thread {
            val iAppDatabase: AppDatabase? = pContext?.let { AppDatabase.getInstance(it) }
            val iMyData = MyData(pTitle, pNameCh, pNameEn, pPosition) //pAreaTitle,
            iAppDatabase?.getDataDao()?.insertData(iMyData) //pMppDatabase.getDataDao().queryClickData(myData);
        }.start()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {

        val iView: View = if (mChangeLayout) {
            LayoutInflater.from(parent.context).inflate(R.layout.all_area_item_2, parent, false)
        } else {
            LayoutInflater.from(parent.context).inflate(R.layout.all_area_item, parent, false)

        }
        return ViewHolder(iView)
    }

    override fun getItemCount(): Int {
        return mDataResult.size
    }

    @SuppressLint("NotifyDataSetChanged")
    private fun changeUi() {
        notifyDataSetChanged()
    }

    //撈資料庫的
    private fun getRoomQuery(
        pHomeTitle: String?,
        pNameCh: String?,
        pNameEn: String?,
        pPosition: Int,
        pContext: Context?,
    ) {
        Thread {
            //顏色有問題
            synchronized(mSynchronizedUsed) {
                val iFindData = mArraySelected.indexOf(pPosition)
                if (iFindData == -1) {
                    val iMyData: MyData? =
                        pContext?.let { AppDatabase.getInstance(it)?.getDataDao()?.queryClickData(pHomeTitle, pNameCh, pNameEn, pPosition) }

                    if (iMyData != null) {
                        mArraySelected.add(pPosition)
                        mHandler.removeCallbacks(mRunnable)
                        mHandler.postDelayed(mRunnable, 500)

                    }
                }
            }
        }.start()
    }


    //點擊跳轉到Detail頁面，傳TitleName 給Detail
    private fun sendBundleGoOtherPage(pTitleName: String?) {
        val iBundle = Bundle()
        iBundle.putString(Parameter.getInstance().KeyRawJson, mDataResult[mPosition].getRawData())
        iBundle.putString(Parameter.getInstance().mKeyTitle, pTitleName) //傳給Detail TitleName

        mGoToPageApplication.goToPage(pTargetFragment = DetailFragment(), pBundle = iBundle)
    }

    //-----class------
    class ViewHolder(v: View) : RecyclerView.ViewHolder(v) {
        var mLayout: LinearLayout = v.findViewById(R.id.mLayout)
        var mImg: ImageView = v.findViewById<View>(R.id.mImgAllAreaItem).findViewById(R.id.mImgAllZoo)
        var mTvNameCh: TextView = v.findViewById<View>(R.id.mTvAllAreaItemNameCh).findViewById(R.id.mTvAllZoo)
        var mTvNameEn: TextView = v.findViewById<View>(R.id.mTvAllAreaItemNameEn).findViewById(R.id.mTvAllZoo)
        var mTextIndex: TextView = v.findViewById<View>(R.id.mTvAllAreaItemIndex).findViewById(R.id.mTvAllZoo)
    }
}