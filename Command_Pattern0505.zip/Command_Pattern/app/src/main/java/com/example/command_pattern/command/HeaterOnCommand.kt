package com.example.command_pattern.command

import com.example.command_pattern.Command
import com.example.command_pattern.equipment.Heater

class HeaterOnCommand(private val mEquipment: Heater) : Command {

    override fun execute() {
        mEquipment.on()

    }

    override fun undo() {
        mEquipment.off()
    }


}