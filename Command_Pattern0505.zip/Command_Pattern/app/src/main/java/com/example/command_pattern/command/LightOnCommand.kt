package com.example.command_pattern.command

import com.example.command_pattern.Command
import com.example.command_pattern.equipment.Light

class LightOnCommand(private val mEquipment: Light) : Command {

    override fun execute() {
        mEquipment.on()
    }

    override fun undo() {
        mEquipment.off()
    }


}