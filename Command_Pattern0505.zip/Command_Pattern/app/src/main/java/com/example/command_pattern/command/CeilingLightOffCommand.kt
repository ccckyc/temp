package com.example.command_pattern.command

import com.example.command_pattern.Command
import com.example.command_pattern.equipment.CeilingLight
import com.example.command_pattern.equipment.Light

class CeilingLightOffCommand(private val mEquipment: CeilingLight) : Command {
    override fun execute() {
        mEquipment.off()
    }

    override fun undo() {
        mEquipment.off()
    }
}