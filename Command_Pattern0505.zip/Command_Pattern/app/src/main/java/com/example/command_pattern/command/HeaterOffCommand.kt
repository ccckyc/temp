package com.example.command_pattern.command

import com.example.command_pattern.Command
import com.example.command_pattern.equipment.Heater
import com.example.command_pattern.equipment.Light

class HeaterOffCommand(private val mEquipment: Heater) : Command {
    override fun execute() {
        mEquipment.off()
    }

    override fun undo() {
        mEquipment.off()
    }
}