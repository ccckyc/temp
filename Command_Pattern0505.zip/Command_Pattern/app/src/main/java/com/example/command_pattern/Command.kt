package com.example.command_pattern

interface Command {
    fun execute()
    fun undo()// 全部關閉
}