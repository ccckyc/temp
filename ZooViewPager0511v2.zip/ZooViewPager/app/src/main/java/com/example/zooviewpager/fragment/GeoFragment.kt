package com.example.zooviewpager.fragment

import android.annotation.SuppressLint
import android.util.Log
import android.webkit.WebViewClient
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.zooviewpager.AllViewModel
import com.example.zooviewpager.R
import com.example.zooviewpager.data.GeoAdapter
import com.example.zooviewpager.databinding.GeoRecyclerviewBinding
import java.util.*

class GeoFragment : BaseFragment<GeoRecyclerviewBinding, AllViewModel>()  {
    //implements GeoAdapter.OnGeoListener
    private var mGeo: ArrayList<String> = ArrayList() //存 detail傳來資料
//    private val mData = ArrayList<String>()

//    var mGeoRecyclerviewBinding: GeoRecyclerviewBinding? = null
    private var mGeoAdapter: GeoAdapter? = null
//    var mToast: Toast? = null

    override val mClass: Class<AllViewModel> get() = AllViewModel::class.java
    override val mLayout: Int get() = R.layout.geo_recyclerview

    private val mGeoListener = object : GeoAdapter.OnGeoListener {
        @SuppressLint("ShowToast")
        override fun onGeoBtnClick(position: Int) {

            mDataBinding.mWebVLink.loadUrl("https://www.google.com/maps/place/" + mGeo[position])

            //Toast不要一直顯示著：先判斷是否有東西 Yes-->cancel   最後在show()
//                if (mToast != null) {
//                    mToast?.cancel()
//                    mToast = Toast.makeText(
//                        activity?.applicationContext,
//                        "click$position", Toast.LENGTH_SHORT
//                    )
//                    Log.v("aaa", "cancel  $position")
//                } else {
//                    mToast = Toast.makeText(
//                        activity?.applicationContext,
//                        "click$position", Toast.LENGTH_SHORT
//                    )
//                }
//                mToast?.show()
            Log.v("aaa", "show  $position")
            Log.v("aaa-----WebView", position.toString() + ":" + "https://www.google.com/maps/place/" + mGeo[position])
        }
    }


    override fun uiInit(pTitle: String?) {
        getGeoData()
        initView()
        if(mGeo.isNotEmpty()) {
            runFirstWebView()
        } else {

        }
    }

//    private GeoViewModel mGeoViewModel;
//    @SuppressLint("SetJavaScriptEnabled")
//    override fun onCreate(savedInstanceState: Bundle?) {
//        super.onCreate(savedInstanceState)
//        mDataBinding = DataBindingUtil.setContentView(requireActivity(), R.layout.geo_recyclerview)
//
//    }



    //抓到 detail傳來資料
    private fun getGeoData() {
        val iBundle = arguments
        mGeo = iBundle?.getStringArrayList("Geo") ?: arrayListOf()
//            val intent = activity?.intent
//            if (intent != null) {
//                mGeo = intent.getStringArrayListExtra("Geo")
//            }
//        Log.v("aaa", "Geo----type" + mGeo?.javaClass?.simpleName)
//        for (i in mGeo.indices) {
//            mData.add(mGeo[i])
//        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    fun runFirstWebView() {
        mDataBinding.mWebVLink.settings.javaScriptEnabled = true
        mDataBinding.mWebVLink.webViewClient = WebViewClient()
        mDataBinding.mWebVLink.loadUrl("https://www.google.com/maps/place/" + mGeo[0])
        Log.v("aaa", "https://www.google.com/maps/place/" + mGeo[0])
    }

//    private void init()
//    {
//        mGeoViewModel = new ViewModelProvider (this).get(GeoViewModel.class);
//        mGeoViewModel.getGeoListObserver().observe(this, new Observer < ArrayList < String > > () {
//            @Override
//            public void onChanged(ArrayList<String> listData) {
//                if (mDataBinding.mGeoRecyclerView.getAdapter() instanceof GeoAdapter) {
//                    GeoAdapter iGeoAdapter =(GeoAdapter) mDataBinding . mGeoRecyclerView . getAdapter ();
//
//                    if (listData != null) {
//                        iGeoAdapter.setData(listData);
//                    }
//
//                }
//            }
//        });
//    }
    @SuppressLint("SetJavaScriptEnabled")
    private fun initView() {

        //
        val iLayoutManager = LinearLayoutManager(requireActivity(), LinearLayoutManager.HORIZONTAL, false)
        mDataBinding.mGeoRecyclerView.layoutManager = iLayoutManager

        //interface 用法1 implements GeoAdapter.OnGeoListener
//        mGeoAdapter = new GeoAdapter(mData, this);

        //interface 用法2
        mGeoAdapter = GeoAdapter(mGeo, mGeoListener)
        mDataBinding.mGeoRecyclerView.adapter = mGeoAdapter
    }


//    //返回時將Toast取消掉
//    override fun onBackPressed() {
//        if (mToast != null) {
//            mToast!!.cancel()
//        }
//        Log.v("aaa", "-------Cancel--------")
//        activity?.finish()
//    } //interface 用法1  implements GeoAdapter.OnGeoListener
}
