package com.example.zooviewpager.roomDataBase

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface ViewPagerDataDao {
    @Query("SELECT * FROM ViewPagerData where (ViewPagerClick = :pFragmentPage)  ")
    fun viewPagerClickData(
        pFragmentPage: Int
    ): ViewPagerData?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertData(mInsertViewPagerData: ViewPagerData?)

}