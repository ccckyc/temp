package com.example.zooviewpager.data.detail

import com.example.zooviewpager.data.list.ListData

class AnimalDetailData : ListData() {
    init {
        typeAnimal()
    }

    override fun getABehavior(): String? {
        return getValue("A_Behavior")
    }

    override fun getADistribution(): String? {
        return getValue("A_Distribution")
    }

    override fun getAClass(): String? {
        return getValue("A_Class")
    }

    override fun getFamily(): String? {
        return getValue("A_Family")
    }

    override fun getPic01ALT(): String? {
        return getValue("A_Pic01_ALT")
    }

    override fun getPic02ALT(): String? {
        return getValue("A_Pic02_ALT")
    }

    override fun getPic03ALT(): String? {
        return getValue("A_Pic03_ALT")
    }

    override fun getPic04ALT(): String? {
        return getValue("A_Pic04_ALT")
    }

    override fun getPic02URL(): String? {
        return getValue("A_Pic02_URL")
    }

    override fun getPic03URL(): String? {
        return getValue("A_Pic03_URL")
    }

    override fun getPic04URL(): String? {
        return getValue("A_Pic04_URL")
    }

    override fun getVedioURL(): String? {
        return getValue("A_Vedio_URL")
    }

    override fun getLocation(): String? {
        return getValue("A_Location")
    }

    override fun getGeo(): String? {
        return getValue("A_Geo")
    }

    override fun isPicEmpty(): Boolean {
        return getPic01Url()?.isEmpty() == true && getPic02URL()?.isEmpty() == true && getPic03URL()?.isEmpty() == true && getPic04URL()?.isEmpty() == true

    }

    override fun isVideoEmpty(): Boolean {
        return getVedioURL() == null || getVedioURL()!!.isEmpty()
    }

    override fun isUrlEmpty(): Boolean {
        return getEUrl() == null || getEUrl()!!.isEmpty()
    }

    override fun isLocationEmpty(): Boolean {
        return getLocation() == null || getLocation()!!.isEmpty()
    }
}