package com.example.zooviewpager

import android.annotation.SuppressLint
import android.content.Context
import android.util.Log
import androidx.lifecycle.MutableLiveData
import com.example.zookotlin.util.Parameter
import com.example.zooviewpager.data.list.ListData
import com.example.zooviewpager.roomDataBase.AppDatabase
import com.example.zooviewpager.roomDataBase.ViewPagerData
import com.google.gson.JsonObject
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import kotlin.collections.ArrayList

class ApiManagerALL {
//    private var mIndex = 0 // pPosition * 20
    private val mLimit = 20
    private var mDataIsFinish = false
    private var mLock = false
    private var mRawResult = ""

    fun callApiData(pList:MutableLiveData<ArrayList<ListData>>, pName: String?, pTitle: String, pFinish: MutableLiveData<Boolean>, pPositionIndex:Int, pContext: Context, pOriginPosition: Int) {
        Log.v("aaa", "--------- IN ---------")
        if (mDataIsFinish || mLock) {

            return
        }
        synchronized(this) { mLock = true }
        Log.v("aaa", "-------- SEND ---------")
        val iService = RetrofitManager.getInstance()!!.createService(APIService::class.java)
        val iCall: Call<JsonObject?>? = when (pTitle) {
            Parameter.getInstance().mKeyPlant -> {
                iService.getPlant(pName, mLimit, pPositionIndex * mLimit)
            }
            Parameter.getInstance().mKeyAnimal -> {
                iService.getAnimal(pName, mLimit, pPositionIndex * mLimit)
            }
            else -> {
                iService.getArea(pTitle, mLimit, pPositionIndex * mLimit) //&q &limit &offset
            }


        }
        iCall?.enqueue(object : Callback<JsonObject?> {
            @SuppressLint("LongLogTag")
            override fun onResponse(call: Call<JsonObject?>, response: Response<JsonObject?>) {
                val iDataResult = ArrayList<ListData>()
//                //抓API
                val iRawResult = response.body().toString()
                mRawResult = iRawResult
                val iJsonObject = JSONObject(mRawResult).getJSONObject("result")
                val iResults = iJsonObject.getJSONArray("results")
                // Log.v("---aaa---ViewModel---callApi---iResults", String.valueOf(iResults));
                for (i in 0 until iResults.length()) {
                    val iListData = ListData()
                    when (pTitle) {
                        Parameter.getInstance().mKeyPlant -> {
                            iListData.typePlant()
                        }
                        Parameter.getInstance().mKeyAnimal -> {
                            iListData.typeAnimal()
                        }
                        else -> {
                            iListData.typeArea()
                        }
                    }
                    iListData.setData(iResults.getJSONObject(i))
                    iDataResult.add(iListData)
                }
//                setRawData(pList, mRawResult, pTitle)
                mDataIsFinish = true
                pFinish.postValue(mDataIsFinish)
                setViewPagerRoom(pOriginPosition, pContext)

                pList.postValue(iDataResult)
            }

            override fun onFailure(call: Call<JsonObject?>, t: Throwable) {}
        })
    }

    private fun setViewPagerRoom(pPosition: Int, pContext: Context) {
        Thread {
            val iAppDatabase: AppDatabase? = pContext.let { AppDatabase.getInstance(it) }
            val iViewPagerData = ViewPagerData().apply {
                mViewPagerDataClick = pPosition
                mViewPagerRawStr = mRawResult }
            iAppDatabase?.getViewPagerDataDao()?.insertData(iViewPagerData)
        }.start()
    }

//    fun setRawData(pList: MutableLiveData<ArrayList<ListData>>, iRawResult: String, pTitle: String): ArrayList<ListData>{
//        val iDataResult = ArrayList<ListData>()
//
//        val iJsonObject = JSONObject(iRawResult)
//        val iResults = iJsonObject.getJSONObject("result").getJSONArray("results")
//
//        // Log.v("---aaa---ViewModel---callApi---iResults", String.valueOf(iResults));
//        for (i in 0 until iResults.length()) {
//            val iListData = ListData()
//            iListData.setData(iResults.getJSONObject(i))
//            when (pTitle) {
//                Parameter.getInstance().mKeyPlant -> {
//                    iListData.typePlant()
//                }
//                Parameter.getInstance().mKeyAnimal -> {
//                    iListData.typeAnimal()
//                }
//                else -> {
//                    iListData.typeArea()
//                }
//            }
//
//            iDataResult.add(iListData)
//        }
//        pList.postValue(iDataResult)
//        return iDataResult
//    }
}
