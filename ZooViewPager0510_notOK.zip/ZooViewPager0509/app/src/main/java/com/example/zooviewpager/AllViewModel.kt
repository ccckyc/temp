package com.example.zooviewpager

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.zooviewpager.data.list.ListData
import com.example.zooviewpager.fragment.ListFragment
import com.example.zooviewpager.roomDataBase.AppDatabase
import com.example.zooviewpager.roomDataBase.MyData
import com.example.zooviewpager.roomDataBase.ViewPagerData
import java.util.*

class AllViewModel : ViewModel() {
    private val mAreaList = MutableLiveData<ArrayList<ListData>>()
    private val mFinish = MutableLiveData<Boolean>()
    private val mNeedToCallApi = MutableLiveData<Boolean>()
    private val mApiManager: ApiManagerALL = ApiManagerALL()
    private val mArraySelected = ArrayList<Int>()
//    var mPositionIndex: Int = 0

    fun getListObserver(): MutableLiveData<ArrayList<ListData>> {
        return mAreaList
    }

    fun getFinish(): MutableLiveData<Boolean> {
        return mFinish
    }

    fun getNeedToCallApi(): MutableLiveData<Boolean> {
        return mNeedToCallApi
    }

    private val mStringName = StringBuilder()
    private val mStringTitle = StringBuilder()


    //將Bundle 取到的區 傳到API 做Query 抓API裡面資料內容
    fun sendApi(pName: String?, pTitle: String?, pPositionIndex: Int, pContext: Context, pOriginPosition: Int){ //: ListFragment.Call?
        mStringName.delete(0, mStringName.length)
        mStringTitle.delete(0, mStringTitle.length)
        mStringName.append(pName)
        mStringTitle.append(pTitle)
//        if (mApiManager == null) {
//            mApiManager = ApiManagerALL()
//        }
        if (pTitle != null) {
            Log.v("aaa", "----- AllViewModel_sendApi -----")
            mApiManager.callApiData(mAreaList, pName, pTitle, mFinish, pPositionIndex, pContext, pOriginPosition)

        }// 抓API裡面資料內容
//        return mCall
    }


    fun getViewPagerListDataRoom(pPosition: Int, pContext: Context) {
        val iViewPagerData: ViewPagerData? = pContext?.let { AppDatabase.getInstance(it)?.getViewPagerDataDao()?.viewPagerClickData(pPosition) }
        Log.v("aaat", pPosition.toString())
//        Log.v("aaat", mArraySelected[pPosition].toString())
//        if (iViewPagerData != null) {
//            iViewPagerData.mViewPagerRawStr?.let {
//                if (it == "") {
//                    mNeedToCallApi.postValue(true)
//                }
//            }
//
//        }
    }

}
