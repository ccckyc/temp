package com.example.templatemethodpattern

import android.util.Log
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import java.util.*

class Coffee : CaffeineBeverage() {
//    override fun prepareRecipe(){
//        boilWater()
//        brewCoffeeGrinds()
//        pourInCup()
//        addSugarAndMilk()
//    }
//    fun boilWater(){}
//    fun pourInCup(){}

//    private fun brewCoffeeGrinds(){
//        println("Dripping Coffee through filter")
//    }
//    private fun addSugarAndMilk(){
//        println("Adding Sugar and milk")
//    }

    override fun brew() {
        Log.v("aaa","Dripping Coffee through filter")
    }
    override fun addCondiments() {
        Log.v("aaa","Adding Sugar and milk")
    }

    override fun customerWantsCondiments(): Boolean {
        val answer: String = getUserInput()
        return answer.lowercase(Locale.getDefault()).startsWith("y")
    }

    private fun getUserInput(): String {
        var answer: String? = null
        Log.v("aaa","Would you like mile and sugar with your coffee (y/n)")
        val `in` = BufferedReader(InputStreamReader(System.`in`))
        try {
            answer = `in`.readLine()
        } catch (ioe: IOException) {
        }
        return answer ?: "no"
    }
}