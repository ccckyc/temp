package com.example.templatemethodpattern

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val tea = Tea()
        val coffee = Coffee()
        println("Making tea...")
        tea.prepareRecipe()
        println("Making coffee...")
        coffee.prepareRecipe()
    }


}