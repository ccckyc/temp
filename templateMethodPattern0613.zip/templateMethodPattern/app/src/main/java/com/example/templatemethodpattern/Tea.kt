package com.example.templatemethodpattern

class Tea : CaffeineBeverage() {
//    override fun prepareRecipe(){
//        boilWater()
//        steepTeaBag()
//        pourInCup()
//        addLemon()
//    }
//    fun boilWater(){}
//    fun pourInCup(){}
//    private fun steepTeaBag(){
//        println("steeping the tea")
//    }
//    private fun addLemon(){
//        println("Adding Lemon")
//    }

    override fun brew() {
        println("steeping the tea")
    }
    override fun addCondiments() {
        println("Adding Lemon")
    }


}