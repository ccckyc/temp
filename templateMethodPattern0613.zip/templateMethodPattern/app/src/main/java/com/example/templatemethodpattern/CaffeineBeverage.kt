package com.example.templatemethodpattern

abstract class CaffeineBeverage {

    fun prepareRecipe(){
        boilWater()
        pourInCup()

        brew()


        if(customerWantsCondiments()){
            addCondiments()
        }
    }


    abstract fun brew()
    abstract fun addCondiments()


    private fun boilWater(){
        println("Boiling Water")
    }
    private fun pourInCup(){
        println("Pouring into cup")
    }

    open fun customerWantsCondiments(): Boolean {
        return true
    }

}