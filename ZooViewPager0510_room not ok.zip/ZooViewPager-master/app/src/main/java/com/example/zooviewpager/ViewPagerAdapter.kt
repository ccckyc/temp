package com.example.zooviewpager

import android.annotation.SuppressLint
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.fragment.app.Fragment
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.example.zooviewpager.data.list.ListData
import com.example.zooviewpager.fragment.ListFragment
import com.example.zooviewpager.roomDataBase.AppDatabase
import com.example.zooviewpager.roomDataBase.MyData
import com.example.zooviewpager.roomDataBase.ViewPagerData

class ViewPagerAdapter(pFragment: Fragment, private var mTabCount: Int) :
    FragmentStateAdapter(pFragment) {
//    val iHash = HashMap<>

    private val mFragment = HashMap<Int, ListFragment>()
    private var mSelectedPosition = -1
    private var mIsRefresh = true
    private val mSynchronizedUsed = "bbb"

    @SuppressLint("NotifyDataSetChanged")
    fun setData(pSize: Int) {
        mTabCount = pSize
        notifyDataSetChanged()
    }

    override fun createFragment(pPosition: Int): Fragment {
        Log.v("aaax", "createFragment = $pPosition")
        // TODO: pPosition 抓點擊過得的再去 ListFragment
        val iListFragment = ListFragment().apply {
            setIndex(pPosition)
        }
        mFragment[pPosition] = iListFragment

        if (mSelectedPosition == pPosition) { //s
            iListFragment.setCanCallApiFlag()
        }

        return iListFragment
    }

    override fun getItemCount(): Int {
        return mTabCount
    }

    @SuppressLint("NotifyDataSetChanged")
    @Synchronized
    fun viewIsFrontGround(pSelectedPosition: Int?) {
        pSelectedPosition?.let {
            Log.v("aaax", "pSelectedPosition = $pSelectedPosition , parentFragment = ${mFragment[it]}, ${mFragment[it]?.parentFragment}")
            Log.v("aaax", "pSelectedPosition = $pSelectedPosition , isDetached = ${mFragment[it]}, ${mFragment[it]?.isDetached}")
            Log.v("aaax", "pSelectedPosition = $pSelectedPosition , isRemoving = ${mFragment[it]}, ${mFragment[it]?.isRemoving}")
            Log.v("aaax", "pSelectedPosition = $pSelectedPosition , activity = ${mFragment[it]}, ${mFragment[it]?.activity}")
            Log.v("aaax", "pSelectedPosition = $pSelectedPosition , mIsRefresh = $mIsRefresh")

            if( mFragment[it]?.activity != null) {
                mFragment[it]?.callApiNow()
            } else if( mFragment[it] != null && mFragment[it]?.activity == null) {
                    mFragment[it]?.setCanCallApiFlag()
            }
            mSelectedPosition = it //s
        }
    }

//    fun getViewPagerRoom(pPosition: Int, pContext: Context, pTitle: String?
//    ) {
//
//        val iViewPagerData: ViewPagerData? =
//            pContext.let { AppDatabase.getInstance(it)?.getViewPagerDataDao()?.viewPagerClickData(pPosition) }
//
//        if (iViewPagerData != null) {
//            Handler(Looper.getMainLooper()).postDelayed({
//                mArraySelected.add(pPosition)
//            }, 500)
//
//
//        }
//    }
}