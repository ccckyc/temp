package com.example.zooviewpager.fragment

import android.app.ProgressDialog
import android.content.Context
import android.util.Log
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.zookotlin.util.Parameter
import com.example.zooviewpager.AllViewModel
import com.example.zooviewpager.R
import com.example.zooviewpager.data.ZooAdapter
import com.example.zooviewpager.data.list.ListData
import com.example.zooviewpager.databinding.ListFragmentBinding
import com.example.zooviewpager.roomDataBase.AppDatabase
import com.example.zooviewpager.roomDataBase.ViewPagerData
import java.lang.Exception
import java.util.*
import kotlin.collections.ArrayList

// Fragment 不能有建構子
class ListFragment : BaseFragment<ListFragmentBinding, AllViewModel>() {
    private var mIsNotFinish = true
    private var mProgressDialog: ProgressDialog? = null
    private var mZooAdapter: ZooAdapter? = null
    var mPositionIndex = 0
    private var mOriginPosition = -1
    private var mIsCallApiStart = false
    private var mListData = ArrayList<ListData>()

    fun setIndex(pPosition: Int) {
        mOriginPosition = pPosition
        if( pPosition < 5) {
            mPositionIndex = pPosition
            setTitle(Parameter.getInstance().mKeyAnimal)
        } else {
            mPositionIndex = pPosition - 5
            setTitle(Parameter.getInstance().mKeyPlant)
        }
    }

    fun setCanCallApiFlag() {
        Log.v("aaax", "----- setCanCallApiFlag ----- $mOriginPosition")
        mIsCallApiStart = true
    }

    fun callApiNow() {
        Log.v("aaax", "----- callApiNow -----$mOriginPosition")
        setCanCallApiFlag()
        if( mIsCallApiStart) {
            if (mIsNotFinish) {
                mCall.callApi()
            }
        }
    }

    private fun setTitle(pTitle: String) {
        super.mTitle = pTitle
    }

    private val mCall: Call by lazy {
        object : Call {
            override fun callApi() {
                loading()
                Log.v("aaax", "----- SendApi -----$mOriginPosition")
                mViewModel.sendApi(null, mTitle, mPositionIndex, requireContext(), mOriginPosition)
                Log.v("aaa", "List_mPositionIndex = $mPositionIndex")
            }
        }
    }

    override val mClass: Class<AllViewModel> get() = AllViewModel::class.java
    override val mLayout: Int get() = R.layout.list_fragment

    // TODO： call 過API 記錄起來 判斷是否要再 callAPI
    override fun uiInit(pTitle: String?) {
        Log.v("aaax", "----- uiInit -----$mOriginPosition")
        initView()
        setViewData()
        mDataBinding.mRecyclerView.adapter = ZooAdapter(pTitle)
        if( mIsCallApiStart) {
            if (mIsNotFinish) {
                mCall.callApi()
            }

        }

    }

    private fun setViewData() {
        mViewModel.getListObserver().observe(this.viewLifecycleOwner, { listData ->
//            Log.v("aaa", "observe bbb")
           mListData = listData
            if (mDataBinding.mRecyclerView.adapter is ZooAdapter) {
                mZooAdapter = mDataBinding.mRecyclerView.adapter as ZooAdapter
//                Log.v("aaa", "observe ccc")
                if (listData != null) {
                    assert(mZooAdapter != null)
//                    Log.v("aaa", "observe ddd")
                    mZooAdapter!!.setData(listData) //抓到APi
                    if (mProgressDialog != null) {
                        mProgressDialog!!.dismiss() //關掉Loading
                    }
                }
            }
        })

//        mViewModel.getFinish().observe(this.viewLifecycleOwner, { itF ->
//            mFinish = itF
//        })
//
        mViewModel.getFinish().observe(this.viewLifecycleOwner, { itFinish ->
            mIsNotFinish = !itFinish
        })

//        mViewModel.getNeedToCallApi().observe(viewLifecycleOwner){
////            callApiNow()
//            if (mDataBinding.mRecyclerView.adapter is ZooAdapter) {
//                mZooAdapter = mDataBinding.mRecyclerView.adapter as ZooAdapter
////                Log.v("aaa", "observe ccc")
//                if (mListData != null) {
//                    assert(mZooAdapter != null)
////                    Log.v("aaa", "observe ddd")
//                    mZooAdapter!!.setData(mListData) //抓到APi
//                    if (mProgressDialog != null) {
//                        mProgressDialog!!.dismiss() //關掉Loading
//                    }
//                }
//            }
//        }
//        getRoom()
    }

    private fun initView() {
        mDataBinding.mRecyclerView.layoutManager = GridLayoutManager(activity, 1)

        //---- 20筆資料到底
        mDataBinding.mRecyclerView.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrollStateChanged(recyclerView: RecyclerView, newState: Int) {
                super.onScrollStateChanged(recyclerView, newState)
                if (newState == RecyclerView.SCROLL_STATE_IDLE) { //當前狀態為停止滑動
                    if (!mIsNotFinish) {
                        if (!mDataBinding.mRecyclerView.canScrollVertically(1)) { // 到達底部
//                            callApiNow()
                            Toast.makeText(requireContext(), "已經到底了~~", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            }
        })

    }

    fun loading() {
        try {
            mProgressDialog = ProgressDialog(requireActivity())
            mProgressDialog!!.setMessage("Loading...")
            mProgressDialog!!.setProgressStyle(ProgressDialog.STYLE_SPINNER)
            mProgressDialog!!.show()
            mProgressDialog!!.setCancelable(false)
        }catch (e: Exception) {

        }
    }


    interface Call {
        fun callApi() //到Fragment實作
    }

//    private fun getRoom(){
//        Thread{
//            mViewModel.getViewPagerListDataRoom(
//                mOriginPosition, this.requireContext(), mTitle
//            )
//        }.start()
//    }

}