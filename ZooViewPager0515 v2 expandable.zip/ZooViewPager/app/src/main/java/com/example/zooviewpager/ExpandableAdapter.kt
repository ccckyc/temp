package com.example.zooviewpager

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

private open class ExpandableAdapter: RecyclerView.Adapter<ExpandableAdapter.ViewHolder>() {

    private val mExpandableDataList = ArrayList<String>()
//    private val mItemClickListener: ItemClickListener? = null

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
      holder.mItemTextView.text = mExpandableDataList[position]


    }

    override fun getItemCount(): Int {
        return mExpandableDataList.size
    }


    protected class ViewHolder(iView: View) : RecyclerView.ViewHolder(iView) {
        var mItemTextView: TextView = iView.findViewById(com.example.zooviewpager.R.id.mTvAllAreaItemNameCh)
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val iView: View = LayoutInflater.from(parent.context).inflate(com.example.zooviewpager.R.layout.expandable_item, parent, false)
        return ViewHolder(iView)
    }
}
