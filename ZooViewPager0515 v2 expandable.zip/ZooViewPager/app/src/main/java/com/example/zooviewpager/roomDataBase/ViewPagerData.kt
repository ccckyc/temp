package com.example.zooviewpager.roomDataBase

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "ViewPagerData")
class ViewPagerData {

    @PrimaryKey
    @ColumnInfo(name = "ViewPagerClick")
    var mViewPagerDataClick = 0

    @ColumnInfo(name = "ViewPagerRawStr")
    var mViewPagerRawStr: String? = null

}